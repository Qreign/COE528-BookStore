/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstoreapp;

/**
 *
 * @author venka
 */

import javafx.collections.*;
import javafx.scene.*;
import javafx.stage.Stage;

public abstract class Screen {
    public abstract Group display(Stage stage);
}
