package bookstoreapp;

/**
 *
 * @author vguru
 */

import java.nio.file.*;
import java.nio.charset.Charset;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class FileManager {

}
